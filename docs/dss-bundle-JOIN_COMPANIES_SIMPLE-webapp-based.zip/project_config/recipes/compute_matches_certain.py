# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ### Read recipe inputs
# 
# Matches

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
matches_ds = dataiku.Dataset("matches")
matches = matches_ds.get_dataframe(infer_with_pandas=False, bool_as_str=True)
matches

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# Corrected data

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
corrected_data = dataiku.Dataset("matches_uncertain_editlog_pivoted").get_dataframe()
corrected_data

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ### Apply edits to matches with distance > 0 or undefined
# 
# First let's have a look at uncertain matches, before edits

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
mask_uncertain = (matches["distance_initial_match"]>0) | (matches["distance_initial_match"].isnull())
matches_uncertain_unedited = matches[mask_uncertain]
matches_uncertain_unedited

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# And after edits

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
commons = dataiku.import_from_plugin("editable-via-webapp", "commons")
primary_keys = ["id_companies_ref"]
corrected_data["last_edit_date"] = ""
matches_uncertain_edited = commons.merge_edits_from_all_df(matches_uncertain_unedited, corrected_data, primary_keys)
matches_uncertain_edited

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ### Define the new "matches uncertain"
# 
# Rows that are still not marked as reviewed

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
matches_uncertain = matches_uncertain_edited[matches_uncertain_edited["reviewed"]!=True]
matches_uncertain

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ### Define "matches certain"
# 
# This is made of two parts:
# 
# * Matches that were previously uncertain but that are now marked as reviewed

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
matches_uncertain_reviewed = matches_uncertain_edited[matches_uncertain_edited["reviewed"]==True] # those where reviewed is True
matches_uncertain_reviewed

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# * Exact matches

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
mask_exact_match = matches["distance_initial_match"]==0
matches[mask_exact_match]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# We concatenate both

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
matches_certain = pd.concat([matches_uncertain_reviewed, matches[mask_exact_match]])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ### Write recipe outputs

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
matches_uncertain_ds = dataiku.Dataset("matches_uncertain")
matches_uncertain_ds.write_schema(matches_ds.read_schema(), dropAndCreate=True)
matches_uncertain_ds.write_dataframe(matches_uncertain, infer_schema=False)

matches_certain_ds = dataiku.Dataset("matches_certain")
matches_certain_ds.write_schema(matches_ds.read_schema(), dropAndCreate=True)
matches_certain_ds.write_dataframe(matches_certain, infer_schema=False)