# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
train_dataset = dataiku.Dataset("train_dataset")
train_dataset_df = train_dataset.get_dataframe()
emails_prepared_scored_editlog_pivoted = dataiku.Dataset("emails_prepared_scored_editlog_pivoted")
emails_prepared_scored_editlog_pivoted_df = emails_prepared_scored_editlog_pivoted.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
commons = dataiku.import_from_plugin("editable-via-webapp", "commons")
primary_keys = ["email_text", "email_version", "user_country", "weekday", "hour_binned", "purchase_binned"]

emails_prepared_scored_editlog_pivoted_df.rename(columns={"prediction": "clicked"}, inplace=True)

emails_prepared_edited_df = commons.merge_edits_from_all_df(train_dataset_df, emails_prepared_scored_editlog_pivoted_df, primary_keys)
emails_prepared_edited_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
emails_prepared_edited_df["clicked"].value_counts()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
emails_prepared_edited = dataiku.Dataset("emails_prepared_edited")
emails_prepared_edited.write_with_schema(emails_prepared_edited_df)